Aplicación web para venta de mangas,  el proceso es simple, se agregan los mangas al carrito en la seccion "productos" o "Productos destacados", una vez se agregaron, se va a la opcion de 
"carrito", ahi se veran reflejados los mangas con precio y cantidad, posterior a eso pedira un formulario que tendra que ser llenado, una
vez completado el formulario, se dara un mini resumen de la venta, cuando se aprete "pasar a pagar", redirigira hacia la pagina de inicio
ya que no se puede trabajar con apis de pago.