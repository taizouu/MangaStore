from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from sesionApp.models import Manga
from .models import Order, UserProfile
from .forms import UserProfileForm

@login_required
def checkout(request):
    cart_key = f'cart_{request.user.id}'
    cart = request.session.get(cart_key, {})

    # Obtén los productos del carrito
    product_ids = [int(product_id) for product_id in cart.keys()]
    products = Manga.objects.filter(id__in=product_ids)

    # Calcula el precio total del pedido
    total_price = sum(product.price * cart[str(product.id)] for product in products)

    # Crea un nuevo pedido
    order = Order.objects.create(user=request.user, total_price=total_price)
    order.products.set(products)

    # Marca los productos como comprados (opcional)
    for product in products:
        product.quantity_sold += cart[str(product.id)]
        product.save()

    # Limpia el carrito
    del request.session[cart_key]

    return render(request, 'checkout.html', {'order': order})

@login_required
def user_profile(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('checkout')  
        else:
            print(form.errors)
    else:
        form = UserProfileForm(instance=user_profile)

    return render(request, 'user_profile.html', {'form': form})