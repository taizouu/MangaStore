from django.db import models
from django.contrib.auth.models import User
from sesionApp.models import Manga 
from django.core.validators import RegexValidator

class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    products = models.ManyToManyField(Manga)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    is_paid = models.BooleanField(default=False)

    def __str__(self):
        return f"Pedido {self.pk} - Usuario: {self.user.username}"


alpha_validator = RegexValidator(r'^[a-zA-Z]+$', 'Ingrese solo caracteres alfabéticos.')
rut_validator = RegexValidator(r'^[\d.-]+$', 'Ingrese solo números, puntos y guiones para el RUT.')
phone_validator = RegexValidator(r'^\d+$', 'Ingrese solo números para el teléfono.')

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=100, validators=[alpha_validator])
    apellido = models.CharField(max_length=100, validators=[alpha_validator])
    rut = models.CharField(max_length=20, validators=[rut_validator])
    direccion = models.TextField()
    telefono = models.CharField(max_length=15, validators=[phone_validator])

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.user.username}"