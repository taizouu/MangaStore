from django import forms
from .models import UserProfile
import re

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['nombre', 'apellido', 'rut', 'direccion', 'telefono']

    def clean_first_name(self):
        data = self.cleaned_data['nombre']
        if not re.match(r'^[a-zA-Z]+$', data):
            raise forms.ValidationError('Ingrese solo caracteres alfabéticos.')
        return data

    def clean_last_name(self):
        data = self.cleaned_data['apellido']
        if not re.match(r'^[a-zA-Z]+$', data):
            raise forms.ValidationError('Ingrese solo caracteres alfabéticos.')
        return data

    def clean_rut(self):
        data = self.cleaned_data['rut']
        if not re.match(r'\d{1,3}(\.\d{3})*-\d{1}', data):
            raise forms.ValidationError('Ingrese el RUT en el formato correcto (ej. 12.345.678-9).')
        return data

    def clean_phone(self):
        data = self.cleaned_data['telefono']
        if not data.isdigit():
            
            raise forms.ValidationError('Ingrese solo números para el teléfono.')
        return data