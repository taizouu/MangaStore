from django.urls import path
from . import views
from .views import user_profile

urlpatterns = [
    path('checkout/', views.checkout, name='checkout'),
    path('user_profile/', user_profile, name='user_profile'),
]
