from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MangaViewSetListCreateView, OrderViewSetListCreateView, UserProfileViewSetListCreateView

router = DefaultRouter()
router.register(r'manga', MangaViewSetListCreateView, basename='manga-list-create')
router.register(r'order', OrderViewSetListCreateView, basename='order-list-create')
router.register(r'userprofile', UserProfileViewSetListCreateView, basename='userprofile-list-create')

urlpatterns = [
    path('', include(router.urls)),
    # Otras URL de tu aplicación...
]
