from rest_framework import serializers
from django.contrib.auth.models import User
from sesionApp.models import Manga
from paymentApp.models import Order, UserProfile

class MangaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Manga
        fields = '__all__'


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username']

class UserProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer()

    class Meta:
        model = UserProfile
        fields = '__all__'

class OrderSerializer(serializers.ModelSerializer):
    user = UserSerializer()
    products = MangaSerializer(many=True)

    class Meta:
        model = Order
        fields = '__all__'
