from rest_framework import viewsets
from paymentApp.models import  Order, UserProfile
from sesionApp.models import  Manga
from .serializers import MangaSerializer, OrderSerializer, UserProfileSerializer

from rest_framework import viewsets
from paymentApp.models import Manga, Order, UserProfile
from .serializers import MangaSerializer, OrderSerializer, UserProfileSerializer
from rest_framework.permissions import IsAuthenticated
from ApiConnect.permissions import IsAdminUser



class MangaViewSetListCreateView(viewsets.ModelViewSet):
    queryset = Manga.objects.all()
    serializer_class = MangaSerializer
    


class OrderViewSetListCreateView(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    
    


class UserProfileViewSetListCreateView(viewsets.ModelViewSet):
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

