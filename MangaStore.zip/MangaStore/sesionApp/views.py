from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import login, logout, authenticate
from .forms import UserRegisterForm
from .models import Manga
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Usuario {username} creado con éxito. ¡Bienvenido!')
            return redirect('home')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Nombre de usuario o contraseña no válidos')
    return render(request, 'login.html')

@login_required
def user_logout(request):
    logout(request)
    return redirect('home')





@login_required
def add_to_cart(request, product_id):
    manga = get_object_or_404(Manga, pk=product_id)

    if manga.stock > 0:
        cart_key = f'cart_{request.user.id}'
        cart = request.session.get(cart_key, {})

        if str(product_id) in cart:
            cart[str(product_id)] += 1
        else:
            cart[str(product_id)] = 1

        request.session[cart_key] = cart

        manga.stock -= 1
        manga.save()

    return redirect('list_products')

@login_required
def view_cart(request):
    cart_key = f'cart_{request.user.id}'
    cart = request.session.get(cart_key, {})
    products_in_cart = {}
    
    for product_id, quantity in cart.items():
        product = get_object_or_404(Manga, id=product_id)
        products_in_cart[product] = quantity

    return render(request, 'view_cart.html', {'cart': products_in_cart})

@login_required
def clear_cart(request):
    cart_key = f'cart_{request.user.id}'
    if cart_key in request.session:
        del request.session[cart_key]
    return redirect('view_cart')

@login_required
def list_products(request):
    products = Manga.objects.all()
    return render(request, 'list_products.html', {'products': products})